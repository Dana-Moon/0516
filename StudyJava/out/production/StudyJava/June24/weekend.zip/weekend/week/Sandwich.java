package June24.weekend.week;

public class Sandwich {
    public static String bread = "빵, 버터, ";
    

    
}